<!-- ======= Footer ======= -->
<footer id="footer" class="footer">
    <div class="copyright">
        &copy; Copyright <strong><span>MediQ</span></strong>. All Rights Reserved
    </div>

    <div class="credits">
        Developed by <a href="developers.php">Devlk Team</a>
    </div>
</footer><!-- End Footer -->